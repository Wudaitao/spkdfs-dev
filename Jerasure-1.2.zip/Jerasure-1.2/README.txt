See technical report CS-08-627 for a description of the code.  

There are two directories:

The home directory contains the jerasure code.

The Examples directory contains the example programs.  

It assumsed that it is a subdirectory of the home directory.
